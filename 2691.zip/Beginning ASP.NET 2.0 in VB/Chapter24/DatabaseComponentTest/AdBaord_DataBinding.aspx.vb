
Partial Class AdBaord_DataBinding
    Inherits System.Web.UI.Page

End Class
