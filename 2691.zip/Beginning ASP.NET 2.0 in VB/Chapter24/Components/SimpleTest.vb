Public Class SimpleTest
    Public Function GetInfo(ByVal param As String) As String
        Return "You invoked SimpleTest.GetInfo() with '" & _
          param & "'"
    End Function
End Class

Public Class SimpleTest2
    Public Function GetInfo(ByVal param As String) As String
        Return "You invoked SimpleTest2.GetInfo() with '" & _
          param & "'"
    End Function
End Class
