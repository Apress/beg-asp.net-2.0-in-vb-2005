Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data

Partial Class AuthorManager_Disconnected
    Inherits System.Web.UI.Page

    Private connectionString As String = _
         WebConfigurationManager.ConnectionStrings("Pubs").ConnectionString

    Protected Sub Page_Load(ByVal sender As Object, _
  ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            FillAuthorList()
        End If
    End Sub

    Private Sub FillAuthorList()
        lstAuthor.Items.Clear()

        ' Define ADO.NET objects.
        Dim selectSQL As String
        selectSQL = "SELECT au_lname, au_fname, au_id FROM Authors"
        Dim con As New SqlConnection(connectionString)
        Dim cmd As New SqlCommand(selectSQL, con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim pubs As New DataSet()

        ' Try to open database and read information.
        Try
            con.Open()

            ' All the information in transferred with one command.
            adapter.Fill(pubs, "Authors")

        Catch err As Exception
            lblResults.Text = "Error reading list of names. "
            lblResults.Text &= err.Message
        Finally
            con.Close()
        End Try

        For Each row As DataRow In pubs.Tables("Authors").Rows
            Dim newItem As New ListItem()
            newItem.Text = row("au_lname") & ", " & _
              row("au_fname")
            newItem.Value = row("au_id").ToString()
            lstAuthor.Items.Add(newItem)
        Next

    End Sub

    Protected Sub cmdNew_Click(ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles cmdNew.Click
        txtID.Text = ""
        txtFirstName.Text = ""
        txtLastName.Text = ""
        txtPhone.Text = ""
        txtAddress.Text = ""
        txtCity.Text = ""
        txtState.Text = ""
        txtZip.Text = ""
        chkContract.Checked = False

        lblResults.Text = "Click Insert New to add the completed record."
    End Sub

    Protected Sub cmdInsert_Click(ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles cmdInsert.Click

        ' Perform user-defined checks.
        ' Alternatively, you could use RequiredFieldValidator controls.
        If txtID.Text = "" Or txtFirstName.Text = "" Or txtLastName.Text = "" Then
            lblResults.Text = "Records require an ID, first name, and last name."
            Return
        End If

        ' Define ADO.NET objects.
        Dim selectSQL As String
        selectSQL = "SELECT * FROM Authors"
        Dim con As New SqlConnection(connectionString)
        Dim cmd As New SqlCommand(selectSQL, con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim dsPubs As New DataSet()

        ' Get the schema information.
        Try
            con.Open()
            adapter.FillSchema(dsPubs, SchemaType.Mapped, "Authors")
        Catch err As Exception
            lblResults.Text = "Error reading schema. "
            lblResults.Text &= err.Message
        Finally
            con.Close()
        End Try

        Dim rowNew As DataRow
        rowNew = dsPubs.Tables("Authors").NewRow()
        rowNew("au_id") = txtID.Text
        rowNew("au_fname") = txtFirstName.Text
        rowNew("au_lname") = txtLastName.Text
        rowNew("phone") = txtPhone.Text
        rowNew("address") = txtAddress.Text
        rowNew("city") = txtCity.Text
        rowNew("state") = txtState.Text
        rowNew("zip") = txtZip.Text
        rowNew("contract") = Val(chkContract.Checked)
        dsPubs.Tables("Authors").Rows.Add(rowNew)

        ' Insert the new record.
        Dim added As Integer = 0
        Try
            ' Create the CommandBuilder.
            Dim cb As New SqlCommandBuilder(adapter)

            ' Retrieve an updated DataAdapter.
            adapter = cb.DataAdapter

            ' Update the database using the DataSet.
            con.Open()
            added = adapter.Update(dsPubs, "Authors")
        Catch Err As Exception
            lblResults.Text = "Error inserting record. "
            lblResults.Text &= err.Message
        Finally
            con.Close()
        End Try

        ' If the insert succeeded, refresh the author list.
        If added > 0 Then
            FillAuthorList()
        End If
    End Sub

End Class
