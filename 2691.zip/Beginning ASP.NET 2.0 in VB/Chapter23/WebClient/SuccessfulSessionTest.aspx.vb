Imports System.Net

Partial Class SuccessfulSessionTest
    Inherits System.Web.UI.Page

    Private ws As New localhost.StockQuote_SessionState()

    Protected Sub cmdGetCounter_Click(ByVal sender As Object, _
  ByVal e As System.EventArgs) Handles cmdGetCounter.Click
        GetCookie()
        Dim wsInfo As localhost.CounterInfo = ws.GetStockUsage("MSFT")
        SetCookie()

        ' Add usage information to the label.
        lblResult.Text &= "<b>Global: " & wsInfo.GlobalRequests.ToString()
        lblResult.Text &= "<br />Session: "
        lblResult.Text &= wsInfo.SessionRequests.ToString() & "<br /></b>"
    End Sub

    Protected Sub cmdCallService_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles cmdCallService.Click
        GetCookie()
        Dim result As Decimal = ws.GetStockQuote("MSFT")
        SetCookie()

        ' Add confirmation message to the label.
        lblResult.Text &= "GetStockQuote With MSFT Returned "
        lblResult.Text &= result.ToString() & "<br />"
    End Sub

    Private Sub GetCookie()
        ' Initialize the proxy class CookieContainer so it can receive cookies.
        ws.CookieContainer = New CookieContainer()

        ' If a cookie is found, place it in the proxy class.
        ' The only reason it won't be found is if this is the first time the
        ' button has been clicked.
        If Not Session("WebServiceCookie") Is Nothing Then
            ' Retrieve the cookie object from session state.
            Dim sessionCookie As Cookie
            sessionCookie = CType(Session("WebServiceCookie"), Cookie)
            ws.CookieContainer.Add(sessionCookie)
        End If
    End Sub

    Private Sub SetCookie()
        ' Retrieve and store the current cookie for next time.
        ' The session is always stored in a special cookie
        ' called ASP.NET_SessionId.
        Dim wsUri As New Uri("http://localhost")

        Dim cookies As CookieCollection
        cookies = ws.CookieContainer.GetCookies(wsUri)
        Session("WebServiceCookie") = cookies("ASP.NET_SessionId")
    End Sub

End Class
