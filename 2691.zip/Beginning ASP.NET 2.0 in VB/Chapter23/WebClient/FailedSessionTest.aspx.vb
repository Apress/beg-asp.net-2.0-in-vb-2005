
Partial Class FailedSessionTest
    Inherits System.Web.UI.Page

    Private ws As New localhost.StockQuote_SessionState()

    Protected Sub cmdGetCounter_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles cmdGetCounter.Click
        Dim wsInfo As localhost.CounterInfo = ws.GetStockUsage("MSFT")

        ' Add usage information to the label.
        lblResult.Text &= "<b>Global: " & wsInfo.GlobalRequests.ToString()
        lblResult.Text &= "<br />Session: "
        lblResult.Text &= wsInfo.SessionRequests.ToString() & "<br /></b>"
    End Sub

    Protected Sub cmdCallService_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles cmdCallService.Click
        Dim result As Decimal = ws.GetStockQuote("MSFT")

        ' Add confirmation message to the label.
        lblResult.Text &= "GetStockQuote With MSFT Returned "
        lblResult.Text &= result.ToString() & "<br />"
    End Sub

End Class
