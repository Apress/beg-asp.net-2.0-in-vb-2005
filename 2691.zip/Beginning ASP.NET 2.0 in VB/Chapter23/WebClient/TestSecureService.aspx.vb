Imports System.Net

Partial Class TestSecureService
    Inherits System.Web.UI.Page

    Protected Sub cmdUnauthenticated_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUnauthenticated.Click
        Dim ws As New localhost.SecureService()
        lblInfo.Text = ws.TestAuthenticated()
    End Sub

    Protected Sub cmdAuthenticated_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAuthenticated.Click
        Dim ws As New localhost.SecureService()

        ' Specity some user credentials for the web service.
        ' This example uses the user account "GuestAccount" with the password
        ' "Guest".
        Dim credentials As New NetworkCredential("GuestAccount", "Guest")
        ws.Credentials = credentials

        lblInfo.Text = ws.TestAuthenticated()
    End Sub

End Class
