Imports System.Web.Services.Protocols

Partial Class TestSoapHeaderService
    Inherits System.Web.UI.Page

    Protected Sub cmdUnauthenticated_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUnauthenticated.Click
        Dim ws As New localhost.StockQuote_SoapSecurity()

        Try
            Dim price As Decimal = ws.GetStockQuote("MSFT")
            lblInfo.Text = "MSFT is at " + price.ToString()
        Catch err As SoapException
            ' This error results because no header was provided.
            lblInfo.Text = err.Message
        End Try
    End Sub

    Protected Sub cmdAuthenticated_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAuthenticated.Click
        Dim ws As New localhost.StockQuote_SoapSecurity()

        Try
            ws.Login("testUser", "openSesame_00")
            Dim price As Decimal = ws.GetStockQuote("MSFT")
            lblInfo.Text = "MSFT is at " + price.ToString()
        Catch err As SoapException
            lblInfo.Text = err.Message
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            ' Create a test user.
            Dim ws As New localhost.StockQuote_SoapSecurity()
            ws.CreateTestUser("testUser", "openSesame_00")
        End If
    End Sub
End Class
