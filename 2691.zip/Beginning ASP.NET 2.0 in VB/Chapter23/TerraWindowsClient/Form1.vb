Public Class Form1
    Private ts As New net.terraservice.TerraService()

    Private Sub cmdShow_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles cmdShow.Click
        ' Retrieve the matching list.
        Dim factsArray() As net.terraservice.PlaceFacts
        factsArray = ts.GetPlaceList(txtPlace.Text, 100, False)

        ' Loop through all the results, and display them.
        For Each facts As net.terraservice.PlaceFacts In factsArray
            ShowPlaceFacts(facts)
        Next
    End Sub

    Private Sub ShowPlaceFacts(ByVal facts As net.terraservice.PlaceFacts)
        Dim newItem As String
        newItem = "Place: " & facts.Place.City & ", "
        newItem &= facts.Place.State & ", " & facts.Place.Country
        lstPlaces.Items.Add(newItem)
    End Sub

End Class
