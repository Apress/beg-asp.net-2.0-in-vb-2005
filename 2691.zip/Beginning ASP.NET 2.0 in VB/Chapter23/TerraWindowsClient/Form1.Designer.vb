<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblChoose = New System.Windows.Forms.Label
        Me.txtPlace = New System.Windows.Forms.TextBox
        Me.lstPlaces = New System.Windows.Forms.ListBox
        Me.cmdShow = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'lblChoose
        '
        Me.lblChoose.Location = New System.Drawing.Point(16, 22)
        Me.lblChoose.Name = "lblChoose"
        Me.lblChoose.Size = New System.Drawing.Size(108, 12)
        Me.lblChoose.TabIndex = 15
        Me.lblChoose.Text = "Choose a location:"
        '
        'txtPlace
        '
        Me.txtPlace.Location = New System.Drawing.Point(140, 18)
        Me.txtPlace.Name = "txtPlace"
        Me.txtPlace.Size = New System.Drawing.Size(120, 21)
        Me.txtPlace.TabIndex = 14
        Me.txtPlace.Text = "Kingston"
        '
        'lstPlaces
        '
        Me.lstPlaces.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstPlaces.IntegralHeight = False
        Me.lstPlaces.Location = New System.Drawing.Point(19, 95)
        Me.lstPlaces.Name = "lstPlaces"
        Me.lstPlaces.Size = New System.Drawing.Size(316, 160)
        Me.lstPlaces.TabIndex = 13
        '
        'cmdShow
        '
        Me.cmdShow.Location = New System.Drawing.Point(140, 42)
        Me.cmdShow.Name = "cmdShow"
        Me.cmdShow.Size = New System.Drawing.Size(120, 28)
        Me.cmdShow.TabIndex = 12
        Me.cmdShow.Text = "Show All Matches"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(350, 272)
        Me.Controls.Add(Me.lblChoose)
        Me.Controls.Add(Me.txtPlace)
        Me.Controls.Add(Me.lstPlaces)
        Me.Controls.Add(Me.cmdShow)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "TerraService Client"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblChoose As System.Windows.Forms.Label
    Friend WithEvents txtPlace As System.Windows.Forms.TextBox
    Friend WithEvents lstPlaces As System.Windows.Forms.ListBox
    Friend WithEvents cmdShow As System.Windows.Forms.Button

End Class
