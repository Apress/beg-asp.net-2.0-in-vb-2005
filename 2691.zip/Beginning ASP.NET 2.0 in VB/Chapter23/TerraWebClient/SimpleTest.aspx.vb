
Partial Class SimpleTest
    Inherits System.Web.UI.Page

    Private ts As New net.terraservice.TerraService()

    Protected Sub cmdShow_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles cmdShow.Click
        ' Create the Place object for Seattle.
        Dim searchPlace As New net.terraservice.Place()
        searchPlace.City = "Seattle"
        searchPlace.State = "Washington"
        searchPlace.Country = "US"

        ' Define the PlaceFacts objects to retrieve your information.
        Dim facts As net.terraservice.PlaceFacts

        ' Call the web service method.
        facts = ts.GetPlaceFacts(searchPlace)

        ' Display the results with the help of a subroutine.
        ShowPlaceFacts(facts)
    End Sub


    Private Sub ShowPlaceFacts(ByVal facts As net.terraservice.PlaceFacts)
        lblResult.Text &= "<b>Place: " & facts.Place.City & "</b><br /><br />"
        lblResult.Text &= facts.Place.State & ", " & facts.Place.Country
        lblResult.Text &= "<br /> Lat: " & facts.Center.Lat.ToString()
        lblResult.Text &= "<br /> Long: " & facts.Center.Lon.ToString()
        lblResult.Text &= "<br /><br />"
    End Sub

    Protected Sub cmdShowAll_Click(ByVal sender As Object, _
     ByVal e As System.EventArgs) Handles cmdShowAll.Click
        ' Retrieve the matching list (for the city Kingston).
        Dim factsArray() As net.terraservice.PlaceFacts
        factsArray = ts.GetPlaceList("Kingston", 100, False)

        ' Loop through all the results, and display them.
        For Each facts As net.terraservice.PlaceFacts In factsArray
            ShowPlaceFacts(facts)
        Next
    End Sub

    Protected Sub cmdShowPic_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles cmdShowPic.Click
        ' Define the search.
        Dim searchPlace As New net.terraservice.Place()
        searchPlace.City = "Seattle"
        searchPlace.State = "Washington"
        searchPlace.Country = "US"

        ' Get the PlaceFacts for Seattle.
        Dim facts As net.terraservice.PlaceFacts
        facts = ts.GetPlaceFacts(searchPlace)

        ' Retrieve information about the tile at the center of Seattle, using
        ' the Scale and Theme enumerations from the terraservice namespace.
        Dim tileData As net.terraservice.TileMeta
        tileData = ts.GetTileMetaFromLonLatPt(facts.Center, _
         net.terraservice.Theme.Photo, net.terraservice.Scale.Scale16m)

        ' Retrieve the image.
        Dim image() As Byte = ts.GetTile(tileData.Id)

        ' Display the image.
        Response.BinaryWrite(image)
    End Sub

End Class
