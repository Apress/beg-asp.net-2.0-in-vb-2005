Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Security

<WebService(Description:="Methods to get stock information.", _
 Namespace:="http://www.prosetech.com/Stocks")> _
Public Class StockQuote_SoapSecurity
    Inherits WebService

    Public KeyHeader As LicenseKeyHeader

    <WebMethod()> _
    <SoapHeader("KeyHeader", Direction:=SoapHeaderDirection.Out)> _
    Public Sub Login(ByVal username As String, ByVal password As String)
        If Membership.ValidateUser(username, password) Then
            ' Generate a license key, and store it in the SOAP header.
            KeyHeader = New LicenseKeyHeader()

            ' Store this user's KeyHeader object in application state.
            Application(KeyHeader.Ticket) = KeyHeader
        Else
            ' Cause an error that will be returned to the client.
            Throw New SecurityException("Unauthorized.")
        End If
    End Sub

    <WebMethod()> _
    <SoapHeader("KeyHeader", Direction:=SoapHeaderDirection.In)> _
    Public Function GetStockQuote(ByVal ticker As String) _
      As Decimal
        If Not VerifyKey(KeyHeader.Ticket) Then
            Throw New SecurityException("Unauthorized.")
        Else
            ' Normal GetStockQuote code goes here.
            Return ticker.Length
        End If
    End Function

    Private Function VerifyKey(ByVal ticket As String) As Boolean
        ' Look up this key to make sure it's valid.
        If Application(ticket) Is Nothing Then
            Return False
        Else
            Return True
        End If
    End Function

    <WebMethod()> _
    Public Sub CreateTestUser(ByVal name As String, ByVal password As String)
        If Membership.GetUser(name) Is Nothing Then
            Dim status As MembershipCreateStatus
            Membership.CreateUser(name, password, "email@none.com", "Question goes here", "Answer goes here", True, status)
            If (status <> MembershipCreateStatus.Success) Then
                Throw New ApplicationException(status.ToString())
            End If
        End If
    End Sub
End Class


Public Class LicenseKeyHeader
    Inherits System.Web.Services.Protocols.SoapHeader

    Public Ticket As String

    Public Sub New(ByVal ticket As String)
        Me.Ticket = ticket
    End Sub

    Public Sub New()
        Ticket = Guid.NewGuid().ToString()
    End Sub
End Class


