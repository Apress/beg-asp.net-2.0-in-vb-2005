Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

<WebService(Description:="Methods to get stock information.", _
 Namespace:="http://www.prosetech.com/Stocks")> _
Public Class StockQuote_SessionState
    Inherits WebService

    <WebMethod(EnableSession:=True)> _
    Public Function GetStockQuote(ByVal ticker As String) As Decimal
        ' Increment counters. This function locks the application
        ' collection to prevent synchronization errors.
        Application.Lock()

        If Application(ticker) Is Nothing Then
            Application(ticker) = 1
        Else
            Application(ticker) = CType(Application(ticker), Integer) + 1
        End If

        Application.UnLock()

        If Session(ticker) Is Nothing Then
            Session(ticker) = 1
        Else
            Session(ticker) = CType(Session(ticker), Integer) + 1
        End If

        ' Return a value representing the length of the ticker.
        Return ticker.Length
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Function GetStockUsage(ByVal ticker As String) As CounterInfo
        Dim result As New CounterInfo()
        result.GlobalRequests = CType(Application(ticker), Integer)
        result.SessionRequests = CType(Session(ticker), Integer)
        Return result
    End Function
End Class

Public Class CounterInfo
    Public GlobalRequests As Integer
    Public SessionRequests As Integer
End Class

