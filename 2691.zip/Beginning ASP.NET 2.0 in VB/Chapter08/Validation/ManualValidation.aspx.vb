
Partial Class ManualValidation
    Inherits System.Web.UI.Page


    Protected Sub cmdOK_Click(ByVal sender As Object, ByVal e As EventArgs) _
  Handles cmdOK.Click

        Dim ErrorMessage As String = "<b>Mistakes found:</b><br>"

        ' Create a variable to represent the input control.
        Dim ctrlInput As TextBox

        ' Search through the validation controls.
        Dim ctrl As BaseValidator

        For Each ctrl In Me.Validators
            If ctrl.IsValid = False Then
                ErrorMessage &= ctrl.ErrorMessage & "<br>"

                ' Find the corresponding input control, and change the
                ' generic Control variable into a TextBox variable.
                ' This allows access to the Text property.
                ctrlInput = CType( _
                  Me.FindControl(ctrl.ControlToValidate), TextBox)
                ErrorMessage &= " * Problem is with this input: "
                ErrorMessage &= ctrlInput.Text & "<br>"
            End If
        Next

        lblMessage.Text = ErrorMessage
    End Sub

End Class
