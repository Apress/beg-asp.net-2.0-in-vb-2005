
Partial Class information
    Inherits System.Web.UI.Page

End Class
