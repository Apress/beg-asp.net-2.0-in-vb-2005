
Partial Class product1
    Inherits System.Web.UI.Page


End Class
