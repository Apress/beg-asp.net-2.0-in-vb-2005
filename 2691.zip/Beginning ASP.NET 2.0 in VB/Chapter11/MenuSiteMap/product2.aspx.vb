
Partial Class product2
    Inherits System.Web.UI.Page

End Class
