Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class MultipleViews
    Inherits System.Web.UI.Page

    Protected Sub cmdApply_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdApply.Click
        Dim ds As DataSet = GetDataSet()

        ' Copy the DataSet so the cached item isn't affected
        ' when we remove columns.
        ds = ds.Copy()

        For Each item As ListItem In chkColumns.Items
            If item.Selected Then
                ds.Tables(0).Columns.Remove(item.Text)
            End If
        Next

        gridPubs.DataSource = ds.Tables(0)
        gridPubs.DataBind()

    End Sub

    ' This method checks the cache for the DataSet,
    ' and re-caches it if needed.
    Private Function GetDataSet() As DataSet
        Dim dsPubs As DataSet
        If Cache("Titles") Is Nothing Then
            dsPubs = RetrieveData()
            Cache.Insert("Titles", dsPubs, Nothing, DateTime.MaxValue, TimeSpan.FromMinutes(2))
            lblCacheStatus.Text = "Created and added to cache."
        Else
            dsPubs = CType(Cache("Titles"), DataSet)
            lblCacheStatus.Text = "Retrieved from cache."
        End If
        Return dsPubs
    End Function

    ' This method performs the database query, if the 
    ' DataSet object isn't available in the cache.
    Private Function RetrieveData() As DataSet
        Dim connectionString As String = _
          WebConfigurationManager.ConnectionStrings("Northwind").ConnectionString
        Dim SQLSelect As String = "SELECT * FROM Customers"
        Dim con As New SqlConnection(connectionString)
        Dim cmd As New SqlCommand(SQLSelect, con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim ds As New DataSet()

        Try
            con.Open()
            adapter.Fill(ds, "Customers")
        Finally
            con.Close()
        End Try

        Return ds
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Cache.Remove("Titles")

            Dim dsPubs As DataSet = GetDataSet()
            
            chkColumns.DataSource = dsPubs.Tables(0).Columns
            chkColumns.DataMember = "Item"
            chkColumns.DataBind()
        End If
    End Sub
End Class
