
Partial Class GridViewStyles
    Inherits System.Web.UI.Page

End Class
