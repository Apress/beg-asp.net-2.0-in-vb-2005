
Partial Class GridViewEdit
    Inherits System.Web.UI.Page

End Class
