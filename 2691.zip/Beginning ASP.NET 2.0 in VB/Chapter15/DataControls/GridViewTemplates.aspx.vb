
Partial Class GridViewTemplates
    Inherits System.Web.UI.Page

End Class
