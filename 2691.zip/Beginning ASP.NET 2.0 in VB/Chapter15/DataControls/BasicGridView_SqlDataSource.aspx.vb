
Partial Class BasicGridView_SqlDataSource
    Inherits System.Web.UI.Page

End Class
