
Partial Class DynamicAdd
    Inherits System.Web.UI.Page

    Protected Sub cmdAddControl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddControl.Click
        Dim ctrl As New HtmlButton()
        ctrl.InnerText = "Dynamic Button"
        Me.Controls.Add(ctrl)
    End Sub
End Class
