
Partial Class XmlDataBinding
    Inherits System.Web.UI.Page

End Class
