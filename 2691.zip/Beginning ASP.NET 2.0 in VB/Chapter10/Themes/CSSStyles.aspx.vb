
Partial Class CSSStyle
    Inherits System.Web.UI.Page

End Class
