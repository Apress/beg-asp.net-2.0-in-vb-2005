
Partial Class ImageInTheme
    Inherits System.Web.UI.Page

End Class
