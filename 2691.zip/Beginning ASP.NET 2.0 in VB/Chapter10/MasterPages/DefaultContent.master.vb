
Partial Class DefaultContent
    Inherits System.Web.UI.MasterPage
End Class

