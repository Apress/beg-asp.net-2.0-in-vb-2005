
Partial Class DefaultContentPage
    Inherits System.Web.UI.Page

End Class
