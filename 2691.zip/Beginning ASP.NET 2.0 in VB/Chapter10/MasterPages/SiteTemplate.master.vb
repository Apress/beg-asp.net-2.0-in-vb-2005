
Partial Class SiteTemplate
    Inherits System.Web.UI.MasterPage
End Class

