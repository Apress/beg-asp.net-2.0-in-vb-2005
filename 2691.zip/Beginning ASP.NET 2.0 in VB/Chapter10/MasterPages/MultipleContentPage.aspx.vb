
Partial Class MultipleContentPage
    Inherits System.Web.UI.Page

End Class
