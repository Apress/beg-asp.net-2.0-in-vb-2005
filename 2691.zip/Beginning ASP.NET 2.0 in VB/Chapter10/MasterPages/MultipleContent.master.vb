
Partial Class MultipleContent
    Inherits System.Web.UI.MasterPage
End Class

