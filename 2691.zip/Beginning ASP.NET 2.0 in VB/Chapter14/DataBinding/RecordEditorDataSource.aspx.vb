
Partial Class RecordEditorDataSource
    Inherits System.Web.UI.Page

End Class
