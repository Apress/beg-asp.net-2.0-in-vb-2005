Imports System.Collections.Generic

Partial Class ManageUsers
    Inherits System.Web.UI.Page

    Protected Sub cmdCreateTestUsers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCreateTestUsers.Click
        Dim createStatus As MembershipCreateStatus
        Membership.CreateUser("joes", "ignreto12__", "joes@domains.com", "How many menus are in tibet?", "16", True, createStatus)
        Membership.CreateUser("sallyr", "ignreto12__", "sally@domains.com", "How many menus are in tibet?", "16", True, createStatus)
        Membership.CreateUser("user014", "ignreto12__", "user014@home.ca", "How many menus are in tibet?", "16", True, createStatus)
        Membership.CreateUser("hmac_r", "ignreto12__", "", "How many menus are in tibet?", "16", True, createStatus)
        Membership.CreateUser("liu_liu", "ignreto12__", "liu@company.com", "How many menus are in tibet?", "16", True, createStatus)

        ' Rebind.
        GridView1.DataSource = Membership.GetAllUsers()
        GridView1.DataBind()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        GridView1.DataSource = Membership.GetAllUsers()
        GridView1.DataBind()
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        Dim list As New List(Of MembershipUser)()
        list.Add(Membership.GetUser(GridView1.SelectedValue.ToString()))
        DetailsView1.DataSource = list
        DetailsView1.DataBind()
    End Sub
End Class
