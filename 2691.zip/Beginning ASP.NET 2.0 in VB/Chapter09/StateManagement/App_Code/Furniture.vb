Public Class Furniture

    Public Name As String
    Public Description As String
    Public Cost As Double

    Public Sub New(ByVal name As String, ByVal description As String, _
    ByVal cost As Double)
        Me.Name = name
        Me.Description = description
        Me.Cost = cost
    End Sub

End Class
