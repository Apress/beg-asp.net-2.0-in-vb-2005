Partial Class NameTextBoxHost
    Inherits System.Web.UI.Page

    Protected Sub cmdGetNames_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGetNames.Click
        lblNames.Text = "<b>First name:</b> "
        lblNames.Text &= NameTextBox1.GetFirstName()
        lblNames.Text &= "<br /><b>Last name:</b> "
        lblNames.Text &= NameTextBox1.GetLastName()

    End Sub
End Class
