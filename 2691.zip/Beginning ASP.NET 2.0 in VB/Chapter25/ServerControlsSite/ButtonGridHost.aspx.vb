
Partial Class ButtonGridHost
    Inherits System.Web.UI.Page

    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
        ButtonGrid1.Rows = Val(txtRows.Text)
        ButtonGrid1.Cols = Val(txtCols.Text)
    End Sub

    Protected Sub ButtonGrid1_GridClick(ByVal Sender As Object, ByVal e As ServerControlsLibrary.GridClickEventArgs) Handles ButtonGrid1.GridClick
        lblInfo.Text = "You clicked: " & e.ButtonName
    End Sub
End Class
