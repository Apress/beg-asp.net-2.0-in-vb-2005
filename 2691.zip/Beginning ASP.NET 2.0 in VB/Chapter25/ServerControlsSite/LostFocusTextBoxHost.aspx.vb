
Partial Class LostFocusTextBoxHost
    Inherits System.Web.UI.Page

End Class
