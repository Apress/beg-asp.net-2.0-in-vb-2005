
Partial Class FormattedCalendarHost
    Inherits System.Web.UI.Page

End Class
