
Partial Class TitledTextBoxHost
    Inherits System.Web.UI.Page

End Class
