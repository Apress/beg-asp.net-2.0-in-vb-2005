
Partial Class LinkMenu
    Inherits System.Web.UI.UserControl

End Class
