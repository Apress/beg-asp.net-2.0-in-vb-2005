Public Class NameTextBox
    Inherits System.Web.UI.WebControls.TextBox

    Private firstName As String
    Private lastName As String

    Public Function GetFirstName() As String
        UpdateNames()
        Return firstName
    End Function

    Public Function GetLastName() As String
        UpdateNames()
        Return lastName
    End Function

    Private Sub UpdateNames()
        Dim commaPos As Integer = Me.Text.IndexOf(",")
        Dim spacePos As Integer = Me.Text.IndexOf(" ")

        Dim nameArray() As String
        If commaPos <> -1 Then
            nameArray = Me.Text.Split(",")
            firstName = nameArray(1)
            lastName = nameArray(0)
        ElseIf spacePos <> -1 Then
            nameArray = Me.Text.Split(" ")
            firstName = nameArray(0)
            lastName = nameArray(1)
        Else
            ' The text has no comma or space.
            ' It cannot be converted to a name.
            Throw New InvalidOperationException()
        End If
    End Sub

End Class

