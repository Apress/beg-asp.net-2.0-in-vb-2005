Imports System.Web.UI

Public Class LostFocusTextBox
    Inherits System.Web.UI.WebControls.TextBox

    Private _alert As String
    Public Property Alert() As String
        Get
            Return _alert
        End Get
        Set(ByVal value As String)
            _alert = value
        End Set
    End Property

    Protected Overrides Sub AddAttributesToRender( _
      ByVal writer As HtmlTextWriter)
        MyBase.AddAttributesToRender(writer)
        writer.AddAttribute("OnBlur", _
          "javascript:alert('" & alert & "')")
    End Sub


End Class
