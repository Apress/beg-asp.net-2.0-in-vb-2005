Imports System.Web.UI

Public Class TitledTextBox
    Inherits System.Web.UI.WebControls.TextBox

    Private _title As String
    Public Property Title() As String
        Get
            Return _title
        End Get
        Set(ByVal value As String)
            _title = value
        End Set
    End Property

    Protected Overrides Sub Render(ByVal writer As HtmlTextWriter)
        ' Add new HTML.
        writer.Write("<h1>" & Title & "</h1>")

        ' Call the base method (so that the text box is rendered).
        MyBase.Render(writer)
    End Sub
End Class

