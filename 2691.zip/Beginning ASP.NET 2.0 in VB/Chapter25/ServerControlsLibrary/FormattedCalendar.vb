Imports System.Drawing
Imports System.Drawing.Text
Imports System.Web.UI.WebControls

Public Class FormattedCalendar
    Inherits System.Web.UI.WebControls.Calendar

    Public Sub New()
        ' Configure the appearance of the calendar table.
        Me.CellPadding = 8
        Me.CellSpacing = 8
        Me.BackColor = Color.LightYellow
        Me.BorderStyle = System.Web.UI.WebControls.BorderStyle.Groove
        Me.BorderWidth = Unit.Pixel(2)
        Me.ShowGridLines = True

        ' Configure the font.
        Me.Font.Name = "Verdana"
        Me.Font.Size = FontUnit.XXSmall

        ' Configure calendar settings.
        Me.FirstDayOfWeek = System.Web.UI.WebControls.FirstDayOfWeek.Monday
        Me.PrevMonthText = "<--"
        Me.NextMonthText = "-->"

        ' Select the current date by default.
        Me.SelectedDate = DateTime.Today
    End Sub

    Protected Overrides Sub OnDayRender(ByVal cell As TableCell, _
    ByVal day As CalendarDay)

        ' Call the base Calendar.OnDayRender method.
        MyBase.OnDayRender(cell, day)

        If day.IsOtherMonth Then
            day.IsSelectable = False
            cell.Text = ""
        Else
            cell.Font.Bold = True
        End If

    End Sub

End Class

