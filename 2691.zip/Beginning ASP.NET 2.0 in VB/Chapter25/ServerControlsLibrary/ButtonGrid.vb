Imports System.Web.UI.WebControls
Imports System.Web.UI

Public Class ButtonGrid
    Inherits System.Web.UI.Control
    Implements IPostBackEventHandler

    Public Event GridClick(ByVal Sender As Object, ByVal e As GridClickEventArgs)

    Public Sub New()
        Rows = 2
        Cols = 2
    End Sub

    Public Property Cols() As Integer
        Get
            Return CType(ViewState("Cols"), Integer)
        End Get
        Set(ByVal Value As Integer)
            ViewState("Cols") = Value
        End Set
    End Property

    Public Property Rows() As Integer
        Get
            Return CType(ViewState("Rows"), Integer)
        End Get
        Set(ByVal Value As Integer)
            ViewState("Rows") = Value
        End Set
    End Property

    Protected Overrides Sub CreateChildControls()
        Dim count As Integer = 0
        For row As Integer = 0 To Rows
            For col As Integer = 0 To Cols
                count += 1

                ' Create and configure a button.
                Dim ctrlB As New Button()
                ctrlB.Width = Unit.Pixel(60)
                ctrlB.Text = count.ToString()

                ' Set the onClick attribute with a reference to
                ' __doPostBack. When clicked, ctrlB will cause a
                ' postback to the current control and return
                ' the assigned text of ctrlB.
                ctrlB.Attributes("onClick") = _
                  Page.ClientScript.GetPostBackEventReference(Me, ctrlB.Text)

                ' Add the button.
                Controls.Add(ctrlB)
            Next

            ' Add a line break.
            Dim ctrlL As New LiteralControl("<br />")
            Controls.Add(ctrlL)
        Next
    End Sub

    Public Overridable Overloads Sub RaisePostBackEvent( _
  ByVal eventArgument As String) _
  Implements IPostBackEventHandler.RaisePostBackEvent

        RaiseEvent GridClick(Me, New GridClickEventArgs(eventArgument))
    End Sub

End Class

Public Class GridClickEventArgs
    Inherits System.EventArgs

    Private _buttonName As String
    Public Property ButtonName() As String
        Get
            Return _buttonName
        End Get
        Set(ByVal Value As String)
            _buttonName = Value
        End Set
    End Property

    Public Sub New(ByVal buttonName As String)
        Me.ButtonName = buttonName
    End Sub

End Class
