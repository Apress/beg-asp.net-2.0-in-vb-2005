Imports System.Web.UI
Imports System.ComponentModel

Public Class ConfigurableRepeater
    Inherits System.Web.UI.WebControls.WebControl

    Public Sub New()
        RepeatTimes = 3
        Text = "Text"
    End Sub

    <Description("The number of times Text will be repeated"), Category("Layout")> _
    Public Property RepeatTimes() As Integer
        Get
            Return CType(ViewState("RepeatTimes"), Integer)
        End Get
        Set(ByVal Value As Integer)
            ViewState("RepeatTimes") = Value
        End Set
    End Property

    Public Property Text() As String
        Get
            Return CType(ViewState("Text"), String)
        End Get
        Set(ByVal Value As String)
            ViewState("Text") = Value
        End Set
    End Property

    Protected Overrides Sub RenderContents(ByVal writer As HtmlTextWriter)
        MyBase.RenderContents(writer)
        Dim i As Integer
        For i = 1 To RepeatTimes
            writer.Write(Text & "<br>")
        Next
    End Sub

End Class
