Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1, _
 EmitConformanceClaims:=True)> _
<WebService(Description:="Gets a quote for a NASDAQ stock.", _
 Namespace:="http://www.prosetech.com/Stocks")> _
Public Class StockQuote
    Inherits System.Web.Services.WebService

    <WebMethod(Description:="Gets a quote for a NASDAQ stock.")> _
    Public Function GetStockQuote(ByVal ticker As String) As Decimal
        Return ticker.Length
    End Function

End Class
