Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<WebService(Description:="Methods to get stock information.", _
 Namespace:="http://www.prosetech.com/Stocks")> _
Public Class StockQuote_DataObject
    Inherits WebService

    <WebMethod(Description:="Gets a price quote for a stock.")> _
    Public Function GetStockQuote(ByVal ticker As String) As StockInfo
        Dim quote As New StockInfo()
        quote.Symbol = ticker
        quote = FillQuoteFromDB(quote)
        Return quote
    End Function

    Private Function FillQuoteFromDB(ByVal lookup As StockInfo) As StockInfo
        ' You can add the appropriate database code here.
        ' For test purposes this function hard-codes
        ' some sample information.
        lookup.CompanyName = "Trapezoid"
        lookup.Price = 400
        lookup.High_52Week = 410
        lookup.Low_52Week = 20
        Return lookup
    End Function
End Class

Public Class StockInfo
    Public Price As Decimal
    Public Symbol As String
    Public High_52Week As Decimal
    Public Low_52Week As Decimal
    Public CompanyName As String
End Class

