Imports System.Net

Partial Class TestWebService
    Inherits System.Web.UI.Page

    Protected Sub cmdCall_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCall.Click
        Dim ws As New localhost.StockQuote_DataObject()

        ' This timeout will apply to all web method calls until it's changed.
        ws.Timeout = 3000   ' 3,000 milliseconds is 3 seconds.

        Try
            ' Call the web service method.
            Dim wsInfo As localhost.StockInfo = ws.GetStockQuote("MSFT")
            lblResult.Text = wsInfo.CompanyName & " is at: " & wsInfo.Price.ToString()

        Catch err As System.Net.WebException
            If err.Status = WebExceptionStatus.Timeout Then
                lblResult.Text = "Web service timed out after 3 seconds."
            Else
                lblResult.Text = "Another type of problem occurred."
            End If
        End Try

    End Sub
End Class
