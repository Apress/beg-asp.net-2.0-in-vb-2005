Public Class BookEntry
    Public _Author As String
    Public _Submitted As Date
    Public _Message As String

    Public Property Author() As String
        Get
            Return _Author
        End Get
        Set(ByVal Value As String)
            _Author = Value
        End Set
    End Property

    Public Property Submitted() As Date
        Get
            Return _Submitted
        End Get
        Set(ByVal Value As Date)
            _Submitted = Value
        End Set
    End Property

    Public Property Message() As String
        Get
            Return _Message
        End Get
        Set(ByVal Value As String)
            _Message = Value
        End Set
    End Property
End Class

