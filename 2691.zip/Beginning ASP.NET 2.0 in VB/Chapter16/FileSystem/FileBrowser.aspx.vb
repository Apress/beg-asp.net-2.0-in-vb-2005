Imports System.IO

Partial Class FileBrowser
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Dim startingDir As String = "c:\"
            lblCurrentDir.Text = startingDir
            ShowFilesIn(startingDir)
            ShowDirectoriesIn(startingDir)
        End If
    End Sub

    Private Sub ShowFilesIn(ByVal dir As String)
        lstFiles.Items.Clear()

        Dim dirInfo As New DirectoryInfo(dir)
        For Each fileItem As FileInfo In dirInfo.GetFiles()
            lstFiles.Items.Add(fileItem.Name)
        Next
    End Sub

    Private Sub ShowDirectoriesIn(ByVal dir As String)
        lstDirs.Items.Clear()

        Dim dirInfo As New DirectoryInfo(dir)
        For Each dirItem As DirectoryInfo In dirInfo.GetDirectories()
            lstDirs.Items.Add(dirItem.Name)
        Next
    End Sub


    Protected Sub cmdBrowse_Click(ByVal sender As Object, ByVal e As EventArgs) _
      Handles cmdBrowse.Click
        ' Browse to the currently selected subdirectory.
        If lstDirs.SelectedIndex <> -1 Then
            Dim newDir As String = Path.Combine(lblCurrentDir.Text, _
  lstDirs.SelectedItem.Text)
            lblCurrentDir.Text = newDir
            ShowFilesIn(newDir)
            ShowDirectoriesIn(newDir)
        End If
    End Sub

    Protected Sub cmdParent_Click(ByVal sender As Object, ByVal e As EventArgs) _
      Handles cmdParent.Click
        ' Browse up to the current directory's parent.
        ' The Directory.GetParent method helps us out.
        Dim newDir As String
        If Directory.GetParent(lblCurrentDir.Text) Is Nothing Then
            ' This is the root directory; there are no more levels.
            Exit Sub
        Else
            newDir = Directory.GetParent(lblCurrentDir.Text).FullName
        End If

        lblCurrentDir.Text = newDir
        ShowFilesIn(newDir)
        ShowDirectoriesIn(newDir)
    End Sub

    Protected Sub cmdShowInfo_Click(ByVal sender As Object, ByVal e As EventArgs) _
      Handles cmdShowInfo.Click
        ' Show information for the currently selected file.
        If lstFiles.SelectedIndex <> -1 Then
            Dim fileName As String = lblCurrentDir.Text.TrimEnd("\")
            fileName &= "\" & lstFiles.SelectedItem.Text
            Dim selFile As New FileInfo(fileName)
            lblFileInfo.Text = "<b>" & selFile.Name & "</b><br>"
            lblFileInfo.Text &= "Size: " & selFile.Length & "<br>"
            lblFileInfo.Text &= "Created: "
            lblFileInfo.Text &= selFile.CreationTime.ToString()
            lblFileInfo.Text &= "<br>Last Accessed: "
            lblFileInfo.Text &= selFile.LastAccessTime.ToString()
        End If
    End Sub

End Class
