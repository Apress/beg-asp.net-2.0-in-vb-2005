Imports System.Web.Configuration

Partial Class ShowSettings
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblTest.Text &= "This app will connect with "
        lblTest.Text &= "the connection string:<br /><b>"
        lblTest.Text &= WebConfigurationManager.AppSettings("ConnectionString")
        lblTest.Text &= "</b><br /><br />"
        lblTest.Text &= "And will execute the SQL Statement:<br />"
        lblTest.Text &= "<b>"
        lblTest.Text &= WebConfigurationManager.AppSettings("SelectSales")
        lblTest.Text &= "</b>"

        ' Get the configuration information for this web application.
        Dim config As Configuration = _
          WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath)

        ' Make the change.
        config.AppSettings.Settings("SelectSales").Value = "SELECT Price FROM Sales"

        ' Save all the changes you've made since retrieving the configuration
        ' information.
        config.Save()


    End Sub
End Class
